---
description: 根据确认的需求生成详细设计
mode: subagent
model: anthropic/claude-sonnet-4-20250514
temperature: 0.1
steps: 8
tools:
  write: true
permission:
  edit: allow
---

# 任务：需求详细设计
1. 读取确认后的需求
2. 输出设计文档：
   - 功能模块拆分
   - 技术方案
   - 文件结构
   - 开发步骤
3. 保存到：需求清单/设计文档.md
4. 完成输出：✅ 需求设计完成