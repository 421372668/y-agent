---
description: 分析并澄清需求，确认可开发版本
mode: subagent
model: anthropic/claude-sonnet-4-20250514
temperature: 0.2
steps: 8
tools:
  write: true
permission:
  edit: allow
---

# 任务：需求澄清
1. 读取已记录的需求
2. 分析模糊点：功能、输入输出、限制、界面、性能
3. 向用户逐一确认
4. 生成【最终可开发需求文档】
5. 保存到需求清单/确认需求.md
6. 完成输出：✅ 需求已确认可开发