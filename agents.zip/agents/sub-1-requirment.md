---
description: 记录需求到 需求清单/README.md
mode: subagent
model: anthropic/claude-sonnet-4-20250514
temperature: 0
steps: 5
tools:
  write: true
  edit: true
permission:
  edit: allow
---

# 任务：记录/更新需求
1. 创建目录：项目根目录/需求清单
2. 将用户需求写入：需求清单/README.md
3. 格式：标题+详情+状态+时间
4. 若已存在，自动更新并保留历史记录
5. 完成后输出：✅ 需求已记录