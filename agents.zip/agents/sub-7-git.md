---
description: Git 提交代码（push 需要用户确认）
mode: subagent
model: anthropic/claude-sonnet-4-20250514
temperature: 0
steps: 4
tools:
  bash: true
permission:
  bash:
    "*": allow
    "git push": ask
---

# 任务：Git提交代码
执行命令：
1. git add .
2. git commit -m "[功能开发] {需求标题}"
3. git push（需用户确认）
完成输出：✅ 代码已提交到仓库