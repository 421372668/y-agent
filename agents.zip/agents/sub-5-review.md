---
description: 检查代码规范 + 与设计一致性
mode: subagent
model: anthropic/claude-sonnet-4-20250514
temperature: 0
steps: 6
tools:
  edit: true
  bash: true
permission:
  edit: allow
  bash:
    "*": allow
---

# 任务：代码检视
1. 检查所有代码文件
2. 检查项：
   - 命名规范
   - 行长度
   - 注释完整性
   - 与设计一致性
3. 输出检视报告
4. 不通过则返回修改
5. 完成输出：✅ 代码检视通过