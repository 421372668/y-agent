---
description: 根据设计文档编写代码 + 构建
mode: subagent
model: anthropic/claude-sonnet-4-20250514
temperature: 0.1
steps: 15
tools:
  write: true
  edit: true
  bash: true
permission:
  edit: allow
  bash:
    "*": allow
---

# 任务：代码开发与构建
1. 读取设计文档
2. 按规范创建项目文件
3. 编写完整可运行代码
4. 安装依赖（pip install / npm install）
5. 执行构建/格式化
6. 完成输出：✅ 代码开发构建完成